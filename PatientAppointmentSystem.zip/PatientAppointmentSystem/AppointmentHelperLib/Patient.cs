﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppointmentHelperLib
{
    public class Patient
    {
       public string Name;
       public String MRN;
    }
}
