﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppointmentHelperLib
{
     public class Department
    {
        public List<String> Doctors = new List<string>();
       public string DepName;
    }
}
