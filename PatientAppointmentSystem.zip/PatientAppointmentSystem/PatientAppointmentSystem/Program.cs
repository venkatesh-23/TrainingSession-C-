﻿using AppointmentHelperLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientAppointmentSystem
{
    /// <summary>
    /// Main Program
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Main method
        /// </summary>
        public static void Main1(string[] args)
        {
            List<Patient> patients = new List<Patient>();
            IAddNewPatientData add = new AddNewPatientData(patients);
            add.AddPatient("john", "532");
            add.AddPatient("Cena", "534");
            add.AddPatient("JohnCena", "533");
            System.Console.WriteLine(add.GetPatients().Count);
            
          
            System.DateTime date1 = new System.DateTime(2015, 3, 10, 2, 15, 10);
            List<PatientAppointment> patientAppointments = new List<PatientAppointment>();
            IAppointmentMaker appointmentMaker = new AppointmentMaker(patientAppointments);
          //  appointmentMaker.MakeAppointment(patients[0],doctors[0],date1);
            List<PatientAppointment> data = appointmentMaker.GetData();
            System.Console.ReadKey();
        }
        public static void Main(string[] args)
        {
            List<Patient> patients = new List<Patient>();
            IAddNewPatientData add = new AddNewPatientData(patients);
            List<Department> departments = new List<Department> {
                new Department{Doctors={"john","paul"},DepName="Neuro"},
                new Department{Doctors={"Alin","Mary"},DepName="cardio"}
            };
            add.AddPatient("john", "532");
            add.AddPatient("Cena", "534");
            add.AddPatient("JohnCena", "533");
            System.Console.WriteLine(add.GetPatients().Count);
            System.Console.WriteLine("Select Department 1.Neuro 2.Cardio");
            int key = Convert.ToInt32(Console.ReadLine());
            System.Console.WriteLine("Select Doctor 2.paul 1.john");
            int Name = Convert.ToInt32(Console.ReadLine());
            System.Console.WriteLine("Select the time slot ");
            string key1 = System.Console.ReadKey().ToString();
            System.DateTime date1 = new System.DateTime(2015, 3, 10, 2, 15, 10);
            List<PatientAppointment> patientAppointments = new List<PatientAppointment>();
            IAppointmentMaker appointmentMaker = new AppointmentMaker(patientAppointments);
            appointmentMaker.MakeAppointment(patients[0], departments[key-1],departments[key-1].Doctors[Name-1] , date1);
            List<PatientAppointment> data = appointmentMaker.GetData();
            System.Console.ReadKey();
             
        }
    }
}
